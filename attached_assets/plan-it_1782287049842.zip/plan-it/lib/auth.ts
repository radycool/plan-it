import { auth } from "@clerk/nextjs/server";
import { prisma } from "./prisma";
import { redirect } from "next/navigation";

/**
 * Loads the current logged-in user's full app record (role, org, client).
 * Use in server components / API routes that require a logged-in user.
 */
export async function getCurrentUser() {
  const { userId } = auth();
  if (!userId) return null;

  const user = await prisma.user.findUnique({
    where: { clerkId: userId },
    include: { org: true, client: true },
  });

  return user;
}

/** Throws/redirects if there's no logged-in app user. Use at the top of protected pages. */
export async function requireUser() {
  const user = await getCurrentUser();
  if (!user) redirect("/sign-in");
  return user;
}

/** Throws/redirects unless the user is on the internal team (admin or editor). */
export async function requireTeam() {
  const user = await requireUser();
  if (user.role !== "TEAM_ADMIN" && user.role !== "TEAM_EDITOR") {
    redirect("/"); // or a 403 page
  }
  return user;
}

/**
 * Checks whether `user` is allowed to view a given clientId's data.
 * Team members can see any client in their org; client approvers only their own client.
 */
export function canAccessClient(
  user: { role: string; orgId: string | null; clientId: string | null },
  clientOrgId: string,
  clientId: string
) {
  if (user.role === "TEAM_ADMIN" || user.role === "TEAM_EDITOR") {
    return user.orgId === clientOrgId;
  }
  if (user.role === "CLIENT_APPROVER") {
    return user.clientId === clientId;
  }
  return false;
}
