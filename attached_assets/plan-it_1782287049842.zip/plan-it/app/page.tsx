import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import Link from "next/link";
import { redirect } from "next/navigation";

export default async function HomePage() {
  const user = await requireUser();

  // Client approvers go straight to their own client's accounts.
  if (user.role === "CLIENT_APPROVER" && user.clientId) {
    redirect(`/clients/${user.clientId}`);
  }

  const clients = await prisma.client.findMany({
    where: { orgId: user.orgId ?? undefined },
    include: { socialAccounts: true },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div className="max-w-3xl mx-auto px-6 py-12">
      <header className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-semibold tracking-tight">Clients</h1>
      </header>

      {clients.length === 0 ? (
        <p className="text-sm text-ink/60">
          No clients yet. Add one in the database, or build a "New client" form next.
        </p>
      ) : (
        <ul className="space-y-3">
          {clients.map((client) => (
            <li key={client.id}>
              <Link
                href={`/clients/${client.id}`}
                className="flex items-center gap-3 rounded-card border border-line bg-white px-4 py-3 hover:border-ink/30 transition-colors"
              >
                <div className="w-9 h-9 rounded-full bg-line flex items-center justify-center text-sm font-medium">
                  {client.name.slice(0, 1)}
                </div>
                <div className="flex-1">
                  <div className="font-medium">{client.name}</div>
                  <div className="text-xs text-ink/50">
                    {client.socialAccounts.length} account
                    {client.socialAccounts.length === 1 ? "" : "s"}
                  </div>
                </div>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
