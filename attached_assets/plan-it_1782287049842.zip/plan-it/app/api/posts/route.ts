import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user || (user.role !== "TEAM_ADMIN" && user.role !== "TEAM_EDITOR")) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { socialAccountId, type, caption, scheduledAt, media } = await req.json();

  if (!socialAccountId || !type || !Array.isArray(media) || media.length === 0) {
    return NextResponse.json(
      { error: "socialAccountId, type, and at least one media item are required" },
      { status: 400 }
    );
  }

  const post = await prisma.post.create({
    data: {
      socialAccountId,
      type,
      caption,
      scheduledAt: scheduledAt ? new Date(scheduledAt) : null,
      createdById: user.id,
      status: "DRAFT",
      media: {
        create: media.map((m: { url: string; type: "IMAGE" | "VIDEO" }, i: number) => ({
          mediaUrl: m.url,
          mediaType: m.type,
          orderIndex: i,
        })),
      },
    },
    include: { media: true },
  });

  return NextResponse.json({ post });
}
