import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const post = await prisma.post.update({
    where: { id: params.id },
    data: { status: "CHANGES_REQUESTED" },
  });

  // TODO: notify the team that changes were requested.

  return NextResponse.json({ post });
}
