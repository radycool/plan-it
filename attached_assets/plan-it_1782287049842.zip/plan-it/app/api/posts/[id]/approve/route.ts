import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const post = await prisma.post.update({
    where: { id: params.id },
    data: { status: "APPROVED" },
  });

  // TODO: notify the team (e.g. via Resend) that this post was approved,
  // and optionally enqueue it for auto-publish in phase 2.

  return NextResponse.json({ post });
}
