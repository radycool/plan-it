import { createUploadthing, type FileRouter } from "uploadthing/next";
import { getCurrentUser } from "@/lib/auth";

const f = createUploadthing();

export const ourFileRouter = {
  postMedia: f({
    image: { maxFileSize: "16MB", maxFileCount: 10 },
    video: { maxFileSize: "256MB", maxFileCount: 5 },
  })
    .middleware(async () => {
      const user = await getCurrentUser();
      if (!user || (user.role !== "TEAM_ADMIN" && user.role !== "TEAM_EDITOR")) {
        throw new Error("Unauthorized");
      }
      return { userId: user.id };
    })
    .onUploadComplete(async ({ file }) => {
      // The client receives file.url back and attaches it to a post via POST /api/posts
      return { url: file.url };
    }),
} satisfies FileRouter;

export type OurFileRouter = typeof ourFileRouter;
