import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user || (user.role !== "TEAM_ADMIN" && user.role !== "TEAM_EDITOR")) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { clientId, socialAccountId, expiresInDays } = await req.json();
  if (!clientId) {
    return NextResponse.json({ error: "clientId required" }, { status: 400 });
  }

  const link = await prisma.shareLink.create({
    data: {
      clientId,
      socialAccountId: socialAccountId ?? null,
      expiresAt: expiresInDays
        ? new Date(Date.now() + expiresInDays * 24 * 60 * 60 * 1000)
        : null,
    },
  });

  const url = `${process.env.NEXT_PUBLIC_APP_URL}/preview/${link.token}`;
  return NextResponse.json({ link, url });
}
