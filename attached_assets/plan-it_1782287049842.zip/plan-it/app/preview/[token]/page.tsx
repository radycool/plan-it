import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import FeedBoard from "@/components/feed/FeedBoard";

export default async function PublicPreviewPage({ params }: { params: { token: string } }) {
  const link = await prisma.shareLink.findUnique({
    where: { token: params.token },
    include: { client: true, socialAccount: true },
  });

  if (!link) notFound();
  if (link.expiresAt && link.expiresAt < new Date()) {
    return (
      <div className="min-h-screen flex items-center justify-center text-center px-6">
        <div>
          <h1 className="text-xl font-semibold mb-2">This link has expired</h1>
          <p className="text-sm text-ink/60">Ask your contact for a new preview link.</p>
        </div>
      </div>
    );
  }

  // Scoped to a single account, or to every account under the client.
  const accounts = link.socialAccountId
    ? await prisma.socialAccount.findMany({ where: { id: link.socialAccountId } })
    : await prisma.socialAccount.findMany({ where: { clientId: link.clientId } });

  const accountIds = accounts.map((a) => a.id);

  const posts = await prisma.post.findMany({
    where: {
      socialAccountId: { in: accountIds },
      // Public viewers should only ever see content that's at least pending review or further along —
      // never raw drafts.
      status: { in: ["PENDING_APPROVAL", "APPROVED", "CHANGES_REQUESTED", "SCHEDULED", "PUBLISHED"] },
    },
    include: { media: { orderBy: { orderIndex: "asc" } }, comments: false },
    orderBy: { createdAt: "desc" },
  });

  // Group posts back under their account for display, in case multiple accounts are in scope.
  const grouped = accounts.map((account) => ({
    account,
    posts: posts.filter((p) => p.socialAccountId === account.id),
  }));

  return (
    <div className="min-h-screen bg-paper">
      <header className="border-b border-line bg-white px-6 py-4">
        <div className="max-w-3xl mx-auto flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-line flex items-center justify-center font-medium">
            {link.client.name.slice(0, 1)}
          </div>
          <div>
            <div className="font-medium">{link.client.name}</div>
            <div className="text-xs text-ink/50">Shared preview · view only</div>
          </div>
        </div>
      </header>

      {grouped.map(({ account, posts }) => (
        <FeedBoard
          key={account.id}
          account={{ id: account.id, handle: account.handle, platform: account.platform, avatarUrl: account.avatarUrl }}
          posts={posts.map((p) => ({ ...p, comments: [] }))}
          currentUserId={null}
          canEdit={false}
          canApprove={false}
          readOnly={true}
        />
      ))}
    </div>
  );
}
