import { requireUser } from "@/lib/auth";
import { canAccessClient } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import Link from "next/link";
import { notFound, redirect } from "next/navigation";

const PLATFORM_LABEL: Record<string, string> = {
  INSTAGRAM: "Instagram",
  LINKEDIN: "LinkedIn",
  TIKTOK: "TikTok",
  FACEBOOK: "Facebook",
};

export default async function ClientPage({ params }: { params: { clientId: string } }) {
  const user = await requireUser();

  const client = await prisma.client.findUnique({
    where: { id: params.clientId },
    include: { socialAccounts: { include: { _count: { select: { posts: true } } } } },
  });

  if (!client) notFound();
  if (!canAccessClient(user, client.orgId, client.id)) redirect("/");

  return (
    <div className="max-w-3xl mx-auto px-6 py-12">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-10 h-10 rounded-full bg-line flex items-center justify-center font-medium">
          {client.name.slice(0, 1)}
        </div>
        <h1 className="text-2xl font-semibold tracking-tight">{client.name}</h1>
      </div>

      <ul className="space-y-3">
        {client.socialAccounts.map((account) => (
          <li key={account.id}>
            <Link
              href={`/clients/${client.id}/accounts/${account.id}`}
              className="flex items-center justify-between rounded-card border border-line bg-white px-4 py-3 hover:border-ink/30 transition-colors"
            >
              <div>
                <div className="font-medium">@{account.handle}</div>
                <div className="text-xs text-ink/50">{PLATFORM_LABEL[account.platform]}</div>
              </div>
              <span className="text-xs text-ink/40">{account._count.posts} posts</span>
            </Link>
          </li>
        ))}
        {client.socialAccounts.length === 0 && (
          <p className="text-sm text-ink/60">No connected accounts yet.</p>
        )}
      </ul>
    </div>
  );
}
