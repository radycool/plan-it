import { requireUser, canAccessClient } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { notFound, redirect } from "next/navigation";
import FeedBoard from "@/components/feed/FeedBoard";

export default async function AccountFeedPage({
  params,
}: {
  params: { clientId: string; accountId: string };
}) {
  const user = await requireUser();

  const account = await prisma.socialAccount.findUnique({
    where: { id: params.accountId },
    include: { client: true },
  });

  if (!account || account.clientId !== params.clientId) notFound();
  if (!canAccessClient(user, account.client.orgId, account.client.id)) redirect("/");

  const posts = await prisma.post.findMany({
    where: { socialAccountId: account.id },
    include: {
      media: { orderBy: { orderIndex: "asc" } },
      comments: { include: { user: true }, orderBy: { createdAt: "asc" } },
    },
    orderBy: { createdAt: "desc" },
  });

  const canEdit = user.role === "TEAM_ADMIN" || user.role === "TEAM_EDITOR";
  const canApprove = canEdit || user.role === "CLIENT_APPROVER";

  return (
    <FeedBoard
      account={{ id: account.id, handle: account.handle, platform: account.platform, avatarUrl: account.avatarUrl }}
      posts={posts}
      currentUserId={user.id}
      canEdit={canEdit}
      canApprove={canApprove}
      readOnly={false}
    />
  );
}
