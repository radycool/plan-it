import "./globals.css";
import { ClerkProvider } from "@clerk/nextjs";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Plan-It — content approval feed",
  description: "Share content previews with clients and collect approvals.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <ClerkProvider>
      <html lang="en">
        <body className="font-body antialiased">{children}</body>
      </html>
    </ClerkProvider>
  );
}
