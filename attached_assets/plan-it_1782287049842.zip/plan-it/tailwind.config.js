/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#16181D",
        paper: "#FAFAF8",
        line: "#E7E5E0",
        accent: "#FF5B36", // signature warm-orange accent, used sparingly for approve/CTA states
        approved: "#2E8B57",
        pending: "#C98A00",
        changes: "#C0392B",
      },
      fontFamily: {
        display: ["'Söhne'", "Inter", "sans-serif"],
        body: ["Inter", "sans-serif"],
      },
      borderRadius: {
        card: "14px",
      },
    },
  },
  plugins: [],
};
