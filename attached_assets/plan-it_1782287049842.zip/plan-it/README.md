# Plan-It

A multi-tenant content preview & approval tool — like Later/Planoly, but built for agencies
to share draft posts (reels, carousels, single posts) with clients for approval before publishing.

Phase 1 (this codebase): manual upload, platform-styled preview feed, client comments/approval,
public no-login share links.
Phase 2 (not yet built): auto-publish to Instagram/LinkedIn APIs once a post is approved.

## Stack
- **Next.js 14** (App Router)
- **Postgres + Prisma**
- **Clerk** — auth (persistent sessions, roles: team admin/editor, client approver)
- **UploadThing** — media uploads
- **Resend** — email notifications (stubbed, see TODOs)
- **Tailwind CSS**

## 1. Install dependencies
```bash
npm install
```

## 2. Set up Postgres
Easiest options: [Supabase](https://supabase.com) or [Neon](https://neon.tech) — both have a free tier
and give you a `DATABASE_URL` instantly. Or run Postgres locally / in Docker.

Copy the env file and fill it in:
```bash
cp .env.example .env
```

Push the schema to your database:
```bash
npm run db:push
```

## 3. Set up Clerk (auth)
1. Create a free app at [clerk.com](https://clerk.com).
2. Copy your publishable + secret keys into `.env`.
3. In the Clerk dashboard, sign up once yourself (use the app's `/sign-up` page after step 5),
   then copy your Clerk **User ID** from the dashboard.
4. Open `scripts/seed.ts` and paste your real Clerk User ID into `REPLACE_WITH_CLERK_USER_ID_TEAM`
   (and create a second Clerk account for testing the client view, if you want one).

## 4. Set up UploadThing (media uploads)
1. Create a free account at [uploadthing.com](https://uploadthing.com), create an app.
2. Copy the secret + app ID into `.env`.

## 5. Seed demo data
```bash
npm run db:seed
```
This creates a demo agency, client ("Acme Coffee Co."), one Instagram account, and two posts
(one pending approval, one draft) so you have something to look at immediately.

## 6. Run it
```bash
npm run dev
```
Visit `http://localhost:3000`. Sign in with the Clerk account whose User ID you pasted into the
seed script — you'll land on the client list (team) or straight into your feed (client approver).

## How the pieces fit together

```
/                                  → client list (team) or redirect (client approver)
/clients/[clientId]                → social accounts for one client
/clients/[clientId]/accounts/[id]  → THE FEED — platform-styled posts, approve/comment
/preview/[token]                   → public, no-login, read-only version of the feed
/sign-in, /sign-up                 → Clerk-hosted auth
```

```
components/feed/
  FeedBoard.tsx          → page layout, account header, post list
  PostCard.tsx           → single post: media + caption + status + approval + comments
  CarouselViewer.tsx     → swipeable media viewer (handles single/carousel/reel)
  StatusBadge.tsx        → draft/pending/approved/changes-requested pill
  ApprovalControls.tsx   → Approve / Request changes buttons
  CommentThread.tsx      → comment list + add-comment form
```

```
app/api/
  posts/route.ts                        → POST: create a new post (team only)
  posts/[id]/comments/route.ts          → POST: add a comment
  posts/[id]/approve/route.ts           → POST: mark approved
  posts/[id]/request-changes/route.ts   → POST: mark changes requested
  share-links/route.ts                  → POST: generate a public preview link
  uploadthing/                          → media upload handling
```

## What's stubbed / TODO for you to fill in
- **Email notifications** — `TODO` comments mark where to call Resend (e.g. "client requested
  changes", "post approved"). Needs `RESEND_API_KEY` and a verified sending domain.
- **"New post" upload UI** — the feed page links to `#new-post`, but the actual upload form
  (drag-drop → UploadThing → POST `/api/posts`) isn't built yet. The API route is ready and
  tested against; you just need a form component calling `useUploadThing("postMedia")` then
  posting the returned URLs to `/api/posts`.
- **"Create share link" UI** — `/api/share-links` works, but there's no button in the UI yet
  to generate one and copy it. Add a button on the client/account page that POSTs there and
  shows the returned `url`.
- **Calendar view** — not built; the feed is currently a reverse-chronological list only.
- **Phase 2 auto-publish** — Instagram Graph API (Business account + Meta App Review required)
  and LinkedIn API integration, triggered when a post hits `APPROVED`, ideally via a job queue
  (e.g. Trigger.dev or BullMQ) since these are async, rate-limited APIs.

## Adding a new client / account (until you build the admin UI)
For now, easiest via Prisma Studio:
```bash
npm run db:studio
```
Create a `Client` row, a `SocialAccount` row under it, and a `User` row with
`role: CLIENT_APPROVER` and that `clientId` (pointing at their real Clerk User ID once they sign up).
