"use client";

import { useState, useTransition } from "react";

export default function ApprovalControls({
  postId,
  status,
}: {
  postId: string;
  status: string;
}) {
  const [isPending, startTransition] = useTransition();
  const [localStatus, setLocalStatus] = useState(status);

  async function act(action: "approve" | "request-changes") {
    startTransition(async () => {
      const res = await fetch(`/api/posts/${postId}/${action}`, { method: "POST" });
      if (res.ok) {
        setLocalStatus(action === "approve" ? "APPROVED" : "CHANGES_REQUESTED");
      }
    });
  }

  if (localStatus === "APPROVED") {
    return <p className="text-sm text-approved font-medium">✓ Approved</p>;
  }

  return (
    <div className="flex gap-2">
      <button
        disabled={isPending}
        onClick={() => act("approve")}
        className="text-sm font-medium px-4 py-1.5 rounded-full bg-approved text-white hover:bg-approved/90 disabled:opacity-50 transition-colors"
      >
        Approve
      </button>
      <button
        disabled={isPending}
        onClick={() => act("request-changes")}
        className="text-sm font-medium px-4 py-1.5 rounded-full border border-line hover:border-ink/40 disabled:opacity-50 transition-colors"
      >
        Request changes
      </button>
    </div>
  );
}
