const STYLES: Record<string, string> = {
  DRAFT: "bg-line text-ink/60",
  PENDING_APPROVAL: "bg-pending/10 text-pending",
  APPROVED: "bg-approved/10 text-approved",
  CHANGES_REQUESTED: "bg-changes/10 text-changes",
  SCHEDULED: "bg-ink/5 text-ink/70",
  PUBLISHED: "bg-ink text-white",
};

const LABEL: Record<string, string> = {
  DRAFT: "Draft",
  PENDING_APPROVAL: "Pending approval",
  APPROVED: "Approved",
  CHANGES_REQUESTED: "Changes requested",
  SCHEDULED: "Scheduled",
  PUBLISHED: "Published",
};

export default function StatusBadge({ status }: { status: string }) {
  return (
    <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${STYLES[status] ?? STYLES.DRAFT}`}>
      {LABEL[status] ?? status}
    </span>
  );
}
