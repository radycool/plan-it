"use client";

import { useState } from "react";
import type { FeedPost, FeedAccount } from "./FeedBoard";
import CarouselViewer from "./CarouselViewer";
import StatusBadge from "./StatusBadge";
import CommentThread from "./CommentThread";
import ApprovalControls from "./ApprovalControls";

export default function PostCard({
  post,
  account,
  currentUserId,
  canApprove,
  readOnly,
}: {
  post: FeedPost;
  account: FeedAccount;
  currentUserId: string | null;
  canApprove: boolean;
  readOnly: boolean;
}) {
  const [open, setOpen] = useState(false);
  const isLinkedIn = account.platform === "LINKEDIN";

  return (
    <article className="rounded-card border border-line bg-white overflow-hidden">
      {/* header: handle + status */}
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-full bg-line flex items-center justify-center text-xs font-medium">
            {account.handle.slice(0, 1).toUpperCase()}
          </div>
          <span className="text-sm font-medium">@{account.handle}</span>
          <span className="text-xs text-ink/40">· {post.type.toLowerCase()}</span>
        </div>
        <StatusBadge status={post.status} />
      </div>

      {/* media: square-ish for IG/TikTok feel, wider card for LinkedIn */}
      <div className={isLinkedIn ? "px-4" : ""}>
        <CarouselViewer media={post.media} rounded={isLinkedIn} aspect={isLinkedIn ? "16/10" : "1/1"} />
      </div>

      {/* caption */}
      {post.caption && (
        <div className="px-4 pt-3 text-sm leading-relaxed whitespace-pre-wrap">
          <span className="font-medium">@{account.handle}</span> {post.caption}
        </div>
      )}

      {post.scheduledAt && (
        <div className="px-4 pt-2 text-xs text-ink/45">
          Scheduled for {new Date(post.scheduledAt).toLocaleString()}
        </div>
      )}

      {/* approval controls — hidden entirely in read-only public view */}
      {!readOnly && canApprove && (
        <div className="px-4 pt-3">
          <ApprovalControls postId={post.id} status={post.status} />
        </div>
      )}

      {/* comments */}
      {!readOnly && (
        <div className="px-4 pb-4 pt-2">
          <button
            onClick={() => setOpen(!open)}
            className="text-xs text-ink/50 hover:text-ink transition-colors"
          >
            {open ? "Hide" : "View"} comments ({post.comments.length})
          </button>
          {open && (
            <CommentThread postId={post.id} comments={post.comments} currentUserId={currentUserId} />
          )}
        </div>
      )}

      {readOnly && <div className="pb-4" />}
    </article>
  );
}
