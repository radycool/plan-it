"use client";

import { useState } from "react";

type Media = { id: string; mediaUrl: string; mediaType: "IMAGE" | "VIDEO"; orderIndex: number };

export default function CarouselViewer({
  media,
  rounded = false,
  aspect = "1/1",
}: {
  media: Media[];
  rounded?: boolean;
  aspect?: string;
}) {
  const [index, setIndex] = useState(0);

  if (media.length === 0) {
    return (
      <div
        className="w-full bg-line/50 flex items-center justify-center text-xs text-ink/40"
        style={{ aspectRatio: aspect }}
      >
        No media uploaded
      </div>
    );
  }

  const current = media[index];

  return (
    <div className="relative">
      <div
        className={`w-full overflow-hidden bg-ink/5 ${rounded ? "rounded-card" : ""}`}
        style={{ aspectRatio: aspect }}
      >
        {current.mediaType === "VIDEO" ? (
          <video src={current.mediaUrl} controls className="w-full h-full object-cover" />
        ) : (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={current.mediaUrl} alt="" className="w-full h-full object-cover" />
        )}
      </div>

      {media.length > 1 && (
        <>
          {index > 0 && (
            <button
              aria-label="Previous"
              onClick={() => setIndex(index - 1)}
              className="absolute left-2 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-white/90 shadow text-sm"
            >
              ‹
            </button>
          )}
          {index < media.length - 1 && (
            <button
              aria-label="Next"
              onClick={() => setIndex(index + 1)}
              className="absolute right-2 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-white/90 shadow text-sm"
            >
              ›
            </button>
          )}
          <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1">
            {media.map((_, i) => (
              <span
                key={i}
                className={`w-1.5 h-1.5 rounded-full ${i === index ? "bg-white" : "bg-white/50"}`}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
