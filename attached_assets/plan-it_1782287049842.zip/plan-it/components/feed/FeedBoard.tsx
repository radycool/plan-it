import PostCard from "./PostCard";

export type FeedPost = {
  id: string;
  type: "SINGLE" | "CAROUSEL" | "REEL" | "STORY";
  caption: string | null;
  status: "DRAFT" | "PENDING_APPROVAL" | "APPROVED" | "CHANGES_REQUESTED" | "SCHEDULED" | "PUBLISHED";
  scheduledAt: Date | null;
  createdAt: Date;
  media: { id: string; mediaUrl: string; mediaType: "IMAGE" | "VIDEO"; orderIndex: number }[];
  comments: { id: string; body: string; createdAt: Date; user: { name: string | null; email: string } }[];
};

export type FeedAccount = {
  id: string;
  handle: string;
  platform: "INSTAGRAM" | "LINKEDIN" | "TIKTOK" | "FACEBOOK";
  avatarUrl: string | null;
};

const PLATFORM_LABEL: Record<string, string> = {
  INSTAGRAM: "Instagram",
  LINKEDIN: "LinkedIn",
  TIKTOK: "TikTok",
  FACEBOOK: "Facebook",
};

export default function FeedBoard({
  account,
  posts,
  currentUserId,
  canEdit,
  canApprove,
  readOnly,
}: {
  account: FeedAccount;
  posts: FeedPost[];
  currentUserId: string | null;
  canEdit: boolean;
  canApprove: boolean;
  readOnly: boolean;
}) {
  return (
    <div className="max-w-xl mx-auto px-4 py-8">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-full bg-line flex items-center justify-center font-medium overflow-hidden">
          {account.avatarUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={account.avatarUrl} alt="" className="w-full h-full object-cover" />
          ) : (
            account.handle.slice(0, 1).toUpperCase()
          )}
        </div>
        <div>
          <div className="font-medium">@{account.handle}</div>
          <div className="text-xs text-ink/50">{PLATFORM_LABEL[account.platform]}</div>
        </div>
        {canEdit && !readOnly && (
          <a
            href="#new-post"
            className="ml-auto text-sm font-medium text-white bg-ink rounded-full px-4 py-2 hover:bg-ink/90 transition-colors"
          >
            New post
          </a>
        )}
      </div>

      {posts.length === 0 ? (
        <div className="rounded-card border border-dashed border-line py-16 text-center text-sm text-ink/50">
          Nothing here yet. {canEdit && !readOnly ? "Upload the first post to get started." : ""}
        </div>
      ) : (
        <div className="space-y-6">
          {posts.map((post) => (
            <PostCard
              key={post.id}
              post={post}
              account={account}
              currentUserId={currentUserId}
              canApprove={canApprove}
              readOnly={readOnly}
            />
          ))}
        </div>
      )}
    </div>
  );
}
