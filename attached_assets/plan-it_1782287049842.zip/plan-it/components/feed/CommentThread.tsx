"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";

type Comment = { id: string; body: string; createdAt: Date; user: { name: string | null; email: string } };

export default function CommentThread({
  postId,
  comments,
  currentUserId,
}: {
  postId: string;
  comments: Comment[];
  currentUserId: string | null;
}) {
  const [body, setBody] = useState("");
  const [isPending, startTransition] = useTransition();
  const router = useRouter();

  function submit() {
    if (!body.trim()) return;
    startTransition(async () => {
      const res = await fetch(`/api/posts/${postId}/comments`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ body }),
      });
      if (res.ok) {
        setBody("");
        router.refresh();
      }
    });
  }

  return (
    <div className="mt-3 space-y-3">
      {comments.map((c) => (
        <div key={c.id} className="text-sm">
          <span className="font-medium">{c.user.name ?? c.user.email}</span>{" "}
          <span className="text-ink/40 text-xs">{new Date(c.createdAt).toLocaleDateString()}</span>
          <p className="text-ink/80">{c.body}</p>
        </div>
      ))}

      {currentUserId && (
        <div className="flex gap-2 pt-1">
          <input
            value={body}
            onChange={(e) => setBody(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && submit()}
            placeholder="Add a comment"
            className="flex-1 text-sm border border-line rounded-full px-3 py-1.5 focus:outline-none focus:border-ink/40"
          />
          <button
            disabled={isPending}
            onClick={submit}
            className="text-sm font-medium text-accent disabled:opacity-50"
          >
            Post
          </button>
        </div>
      )}
    </div>
  );
}
