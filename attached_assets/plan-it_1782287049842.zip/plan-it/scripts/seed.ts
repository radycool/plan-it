import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  console.log("Seeding demo data...");

  const org = await prisma.org.create({ data: { name: "Your Agency" } });

  // IMPORTANT: replace clerkId values with real Clerk user IDs after you create
  // accounts in Clerk's dashboard (or sign up once and copy the ID from the
  // Clerk dashboard / `auth().userId`). Until then these rows won't log in as anyone.
  const teamUser = await prisma.user.create({
    data: {
      clerkId: "REPLACE_WITH_CLERK_USER_ID_TEAM",
      email: "team@youragency.com",
      name: "You",
      role: "TEAM_ADMIN",
      orgId: org.id,
    },
  });

  const client = await prisma.client.create({
    data: { name: "Acme Coffee Co.", orgId: org.id },
  });

  await prisma.user.create({
    data: {
      clerkId: "REPLACE_WITH_CLERK_USER_ID_CLIENT",
      email: "client@acmecoffee.com",
      name: "Acme Marketing Lead",
      role: "CLIENT_APPROVER",
      clientId: client.id,
    },
  });

  const account = await prisma.socialAccount.create({
    data: {
      clientId: client.id,
      platform: "INSTAGRAM",
      handle: "acmecoffee",
    },
  });

  await prisma.post.create({
    data: {
      socialAccountId: account.id,
      type: "SINGLE",
      caption: "New seasonal blend dropping Friday ☕️ #acmecoffee",
      status: "PENDING_APPROVAL",
      createdById: teamUser.id,
      media: {
        create: [
          {
            mediaUrl: "https://placehold.co/1080x1080/png?text=Post+1",
            mediaType: "IMAGE",
            orderIndex: 0,
          },
        ],
      },
    },
  });

  await prisma.post.create({
    data: {
      socialAccountId: account.id,
      type: "CAROUSEL",
      caption: "Behind the scenes at our roastery 🌱",
      status: "DRAFT",
      createdById: teamUser.id,
      media: {
        create: [
          { mediaUrl: "https://placehold.co/1080x1080/png?text=Slide+1", mediaType: "IMAGE", orderIndex: 0 },
          { mediaUrl: "https://placehold.co/1080x1080/png?text=Slide+2", mediaType: "IMAGE", orderIndex: 1 },
          { mediaUrl: "https://placehold.co/1080x1080/png?text=Slide+3", mediaType: "IMAGE", orderIndex: 2 },
        ],
      },
    },
  });

  console.log("Done. Client ID:", client.id, "Account ID:", account.id);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
