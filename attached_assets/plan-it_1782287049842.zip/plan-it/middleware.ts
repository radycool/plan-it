import { authMiddleware } from "@clerk/nextjs";

// Everything under /preview/[token] is the no-login public share view.
// Everything else requires auth.
export default authMiddleware({
  publicRoutes: [
    "/preview/(.*)",
    "/api/share-links/(.*)/posts", // public read endpoint used by the preview page
  ],
});

export const config = {
  matcher: ["/((?!.*\\..*|_next).*)", "/", "/(api|trpc)(.*)"],
};
